//
//  Vector.swift
//  Bridge
//
//  Created by 许Bill on 15-3-5.
//  Copyright (c) 2015年 Fudan.SS. All rights reserved.
//

import Foundation
class Vector {
    var properties = ["运动","影视","歌舞","学术","动漫","游戏","美食","文艺","就业"]
    class func getVectorList() ->[String]{
        return ["运动","影视","歌舞","学术","动漫","游戏","美食","文艺","就业"]
    }
}