//
//  Poster.swift
//  Bridge
//
//  Created by 许Bill on 15-2-24.
//  Copyright (c) 2015年 Fudan.SS. All rights reserved.
//

import Foundation
import Parse
class Poster: PFObject,PFSubclassing {
    //Attribute of a certain class
    var posterDescription:String = ""
    var posterOf:Activity
    var posterPicture:PFFile?
    
    override init(){
        self.posterOf = Activity()
        super.init()
        
    }
    //The methods to subclass a instance
    init(newPFObject:PFObject){
        self.posterPicture = newPFObject["PosterPicture"] as PFFile?
        self.posterDescription = newPFObject["Description"] as String
        self.posterOf = newPFObject["PosterOf"] as Activity
        
        super.init()
    }
    override init!(className newClassName: String!) {
        self.posterOf = Activity()
        super.init(className: newClassName)
    }
    
    //The method to implement the parent Class's function
    //Don't modify
    override class func initialize() {
        var onceToken : dispatch_once_t = 0;
        dispatch_once(&onceToken) {
            self.registerSubclass()
        }
    }
    override class func load() {
        superclass()?.load()
        self.registerSubclass()
    }
    
    class func parseClassName() -> String! {
        return "Poster"
    }
}