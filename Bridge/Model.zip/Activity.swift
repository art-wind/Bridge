//
//  Activity.swift
//  Bridge
//
//  Created by 许Bill on 15-2-24.
//  Copyright (c) 2015年 Fudan.SS. All rights reserved.
//

import Foundation
import Parse
class Activity: PFObject,PFSubclassing {
    //Attribute of a certain class
    var activityName:String = ""
    var startDate:NSDate = NSDate()
    var duration:String?
    var frequency:String?
    var activityDescription:String = ""
    var icon:PFFile?
    var activityPlace:String?
    
    
    
    //The methods to subclass a instance
    init(newPFObject:PFObject){
        self.activityName = newPFObject["activityName"] as String
        self.startDate = newPFObject["startDate"] as NSDate
        if let optionalDes = newPFObject["activityDescription"] as? String {
            self.activityDescription = optionalDes
        }
        self.frequency = newPFObject["frequency"] as String?
        self.icon = newPFObject["Icon"] as PFFile?
        self.duration = newPFObject["duration"] as String?
        self.activityPlace = newPFObject["activityPlace"] as String?
        super.init()
    }
    override init!(className newClassName: String!) {
        super.init(className: newClassName)
    }
    
    //The method to implement the parent Class's function
    //Don't modify
    override init(){
        super.init()        
    }
    override class func initialize() {
        var onceToken : dispatch_once_t = 0;
        dispatch_once(&onceToken) {
            self.registerSubclass()
        }
    }
    override class func load() {
        superclass()?.load()
        self.registerSubclass()
    }
    
    class func parseClassName() -> String! {
        return "Activity"
    }
}